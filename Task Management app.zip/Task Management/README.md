# Tasky bootstrap

 Task Management project using DOM Manipulation
 
 Task cards can be added or deleted
 

![tasky](https://user-images.githubusercontent.com/84318379/137151373-a80f0da1-3515-42c7-b6c7-4d550c025fbe.png)


 add
----
![edit](https://user-images.githubusercontent.com/84318379/137151717-ef525fd5-0a19-4d00-a963-da808f31efbe.png)

![work](https://user-images.githubusercontent.com/84318379/137151885-006f0691-ae86-4f6f-887f-7bdd5c8cd8a8.png)

 Responsive
----------

![responsive](https://user-images.githubusercontent.com/84318379/137152097-2bddb0be-18c5-4c39-bc3b-80a655df4b90.png)

edit
-----
![write](https://user-images.githubusercontent.com/84318379/137152268-bcb53802-1fe5-4dad-8ab8-2a1cc50c7515.png)

Delete
-----
![delete](https://user-images.githubusercontent.com/84318379/137152414-27d0b721-2fca-472f-aa03-ddac881761a2.png)
